import tensorflow as tf
import numpy as np
from flask import Flask, jsonify, render_template, request
import json

# Load models
model_reg = tf.keras.models.load_model("mnist/data/regression_model")
model_conv = tf.keras.models.load_model("mnist/data/convolutional_model")

app = Flask(__name__)

def regression(input):
    return model_reg.predict(input).flatten().tolist()

def convolutional(input):
    return model_conv.predict(input.reshape(-1, 28, 28, 1)).flatten().tolist()

@app.route('/api/mnist', methods=['POST'])
def mnist():
    # 读取输入数据并调整形状为 (1, 28*28)
    input_data = ((255 - np.array(request.json, dtype=np.uint8)) / 255.0).reshape(1, 784)

    # 调整为三维输入 (1, 1, 784) 以匹配模型期望输入
    input_data = np.expand_dims(input_data, axis=1)

    # 通过两个模型进行预测
    output1 = regression(input_data)
    output2 = convolutional(input_data)

    # 将输出结果合并
    output = {
        "output1": output1,
        "output2": output2
    }

    return jsonify(site=[output])

@app.route('/')
def main():
    return render_template('index.html')

if __name__ == "__main__":
    app.debug = True
    app.run(port=8000)