import os
import tensorflow as tf
import tensorflow_datasets as tfds

# Load MNIST data using tensorflow_datasets
def load_data(batch_size=64):
    (train_data, test_data), ds_info = tfds.load(
        'mnist',
        split=['train', 'test'],
        as_supervised=True,
        with_info=True
    )

    # Normalize and preprocess the data
    def preprocess(image, label):
        image = tf.cast(image, tf.float32) / 255.0  # Normalize to [0, 1]
        image = tf.reshape(image, (28, 28, 1))  # Reshape to match input shape
        label = tf.one_hot(label, depth=10)  # One-hot encoding of labels
        return image, label

    # Cache the dataset and prefetch for performance
    train_data = train_data.map(preprocess).cache().batch(batch_size).prefetch(tf.data.AUTOTUNE)
    test_data = test_data.map(preprocess).batch(batch_size).prefetch(tf.data.AUTOTUNE)

    return train_data, test_data

train_data, test_data = load_data(batch_size=50)


# Define the convolutional model
class ConvModel(tf.keras.Model):
    def __init__(self):
        super(ConvModel, self).__init__()
        self.conv1 = tf.keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same')
        self.pool1 = tf.keras.layers.MaxPooling2D((2, 2))
        self.conv2 = tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same')
        self.pool2 = tf.keras.layers.MaxPooling2D((2, 2))
        self.flatten = tf.keras.layers.Flatten()
        self.fc = tf.keras.layers.Dense(128, activation='relu')
        self.output_layer = tf.keras.layers.Dense(10, activation='softmax')

    def call(self, inputs):
        x = self.conv1(inputs)
        x = self.pool1(x)
        x = self.conv2(x)
        x = self.pool2(x)
        x = self.flatten(x)
        x = self.fc(x)
        return self.output_layer(x)


# Initialize and compile the convolutional model
model_conv = ConvModel()
model_conv.build(input_shape=(None, 28, 28, 1))  # Define input shape

# Compile model
model_conv.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
                   loss='categorical_crossentropy',
                   metrics=['accuracy'])
#
# # Define callbacks for training
# callbacks = [
#     tf.keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True),
#     tf.keras.callbacks.TensorBoard(log_dir=os.path.join(os.path.dirname(__file__), 'logs'), histogram_freq=1)
# ]

# Train the model
# model_conv.fit(train_data, epochs=20, validation_data=test_data, callbacks=callbacks)
model_conv.fit(train_data, epochs=20, validation_data=test_data)

# Save the model as SavedModel format
model_conv.save(os.path.join(os.path.dirname(__file__), 'data', 'convolutional_model'), save_format='tf')