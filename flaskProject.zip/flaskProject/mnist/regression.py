import os
import tensorflow as tf
import tensorflow_datasets as tfds
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
# Load MNIST data using tensorflow_datasets
def load_data():
    (train_data, test_data), ds_info = tfds.load(
        'mnist',
        split=['train', 'test'],
        as_supervised=True,
        with_info=True
    )

    # Normalize and preprocess the data
    def preprocess(image, label):
        image = tf.cast(image, tf.float32) / 255.0  # Normalize to [0, 1]
        image = tf.reshape(image, (28, 28, 1))  # Reshape to match input shape
        return image, tf.one_hot(label, 10)  # One-hot encoding of labels

    train_data = train_data.map(preprocess).batch(50)
    test_data = test_data.map(preprocess).batch(100)

    return train_data, test_data

train_data, test_data = load_data()

# Define the regression model
class RegressionModel(tf.keras.Model):
    def __init__(self):
        super(RegressionModel, self).__init__()
        self.dense1 = tf.keras.layers.Dense(128, activation='relu')
        self.dense2 = tf.keras.layers.Dense(10, activation='softmax')

    def call(self, inputs):
        x = self.dense1(inputs)
        return self.dense2(x)

# Initialize and compile the regression model
model_reg = RegressionModel()

model_reg.build(input_shape=(None, 784))  # 线性回归模型
# Prepare train and test data for regression model
def flatten_images(images, labels):
    images = tf.reshape(images, (-1, 28 * 28))  # Flatten images
    return images, labels

train_data_reg = train_data.map(flatten_images).batch(100)
test_data_reg = test_data.map(flatten_images).batch(100)

model_reg.compile(optimizer=tf.keras.optimizers.SGD(0.01),
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

# Train the model
model_reg.fit(train_data_reg, epochs=20, validation_data=test_data_reg)

# Save the model as SavedModel format
model_reg.save(os.path.join(os.path.dirname(__file__), 'data', 'regression_model'), save_format='tf')
